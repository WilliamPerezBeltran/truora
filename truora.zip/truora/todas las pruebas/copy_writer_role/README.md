figma.com un mocka interactivo que se puede utilizar para crear mockup


https://www.figma.com/proto/4OiGiWAZRHddosPygA6zAS/ReOptimize?node-id=736-1723&scaling=min-zoom&page-id=426%3A2154&starting-point-node-id=736%3A1723
