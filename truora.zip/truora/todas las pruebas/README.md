En las raiz va a encontrar varios folder que contiene pruebas de truora.

Por otro lado existe data.txt read_write_file.js y create_folders.sh estos archivos se utilizaron para la creacion de las carpetas automaticamente
El archivo read_write_file.js se utilizo para crear adecuadamente los titulos de cada carpeta.
El archivo create_folders.sh se utilizo para la parte de linux (crear las carpetas utilizando el archivo data.txt que contiene todos los nombres de las carpetas que
queriasmos crear .
